function o(r,t,l){if(r!=="custom")return r;if(!t||!l)return"all";const c=t.replaceAll("-",""),n=l.replaceAll("-","");return`custom_${c}_${n}`}export{o as t};
