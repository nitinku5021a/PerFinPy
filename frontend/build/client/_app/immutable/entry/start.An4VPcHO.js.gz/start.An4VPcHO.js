import{a as t}from"../chunks/entry.BY7ttrNZ.js";export{t as start};
